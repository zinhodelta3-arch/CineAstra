# Cobertura de requisitos

Atualize linhas afetadas por tarefa; não reescreva uma matriz completa a cada rodada.
Não considere frontend/infraestrutura implementados somente por existir endpoint.

| Requisito | Tarefa | Estado | Arquivo/rota | Teste/evidência | Bloqueio |
| --- | --- | --- | --- | --- | --- |
| A preencher conforme implementação | 00 | Pendente | — | — | Diagnóstico |
