# Decisões compartilhadas

Preencher na tarefa 00; depois atualizar somente decisões novas/alteradas.
Este arquivo ainda não descreve o repositório real.

| Tema | Decisão e evidência |
| --- | --- |
| Raiz do backend / frontend | A identificar |
| Node / Express / MySQL / módulos | A identificar |
| Gerenciador / comandos start, lint, teste, migrations | A identificar no package.json |
| Prefixo, DTOs, erros, OpenAPI | Preservar contratos existentes; identificar |
| Migrations aplicadas / V4 | Conferir banco de desenvolvimento ou histórico |
| Dinheiro / BIGINT / datas / fuso | Definir representação exata e consistente |
| JWT, sessões, 2FA, CSRF, proxy e limites | Definir pelo ambiente real |
| Perfis, dono e vínculos operacionais | Mapear por endpoint/contexto |
| Reserva/estoque/pagamento/idempotência | Definir contratos antes do checkout |
| Provedores reais / ausentes | Registrar interfaces e bloqueios |

## Lacunas conhecidas nos anexos
- UNIQUE do assento em itens históricos impede revenda após cancelamento.
- Custos/parâmetros, promoções e benefícios não estão completamente persistidos.
- Convite ACEITO não representa saída, suspensão e mudança no ciclo seguinte.
- Métodos/pagamentos precisam tokenização, webhooks, idempotência e reembolsos.
- Idade/responsável, consentimentos, entrada/saída e suporte histórico exigem modelo.
- Status operacionais RF14 diferem dos financeiros; sessão atravessando meia-noite.
- Expiração/quantidade/finalidade dos tickets e vínculo da retirada de combo.
- 2FA precisa enrollment/desafio/replay e autenticação precisa revogação.
- nome_fantasia virou nome_cine; consultas antigas precisam ajuste.
- Galerias/newsletter já existem no V4; colunas geradas são somente leitura.
- Logs HTTP têm expurgo de 90 dias; retenção de negócio é decisão separada.

Registre solução/migration mínima e tarefa responsável por cada lacuna pertinente.
